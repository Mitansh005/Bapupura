import { useState, useEffect, useRef } from 'react';

type Page = 'home' | 'darshan' | 'albums' | 'upload' | 'about';
type Lang = 'en' | 'gu';

// ─── PALETTE ────────────────────────────────────────────────────────────────
const C = {
  bg: '#FDF6EC', bg2: '#FFF9F3', white: '#FFFFFF',
  gold: '#B5780A', goldL: 'rgba(181,120,10,0.15)', goldLL: 'rgba(181,120,10,0.07)',
  sf: '#C85A0A', maroon: '#7A1515', maroonL: 'rgba(122,21,21,0.07)',
  tx: '#1A0F05', tx2: '#5C4A32', tx3: '#9A8268',
  bd: 'rgba(181,120,10,0.18)', bd2: 'rgba(181,120,10,0.1)',
};

// ─── TRANSLATIONS ────────────────────────────────────────────────────────────
const T = {
  en: {
    nav: { home: 'Home', darshan: 'Live Darshan', albums: 'Albums', upload: 'Upload', about: 'About', lang: 'ગુજ' },
    hero: {
      organizer: 'Shri Shivshakti Ras Mandal & Shri Bapupura Yuva Ekta Manch',
      eventName: 'Shri Nilkanth Mahadev\nMaha Mahotsav',
      dates: '22 – 25 October 2026',
      location: 'Shri Nilkanth Mahadev Mandir, Bapupura',
      address: 'Bapupura, Ta-Mansa, Dis-Gandhinagar, Gujarat',
      cta1: 'View Albums', cta2: 'Live Darshan',
      mantra: '।। Om Namah Shivay ।।',
      countdownLabel: 'Festival begins in',
      D: 'Days', H: 'Hours', M: 'Mins', S: 'Secs',
    },
    darshan: {
      eye: 'Sacred Live Feed',
      title: 'Shri Nilkanth Mahadev — Live Darshan',
      sub: 'Watch live from the sacred temple, anytime from anywhere in the world.',
      camLabel: '🔴 Shri Nilkanth Mahadev Mandir — Live Camera · Bapupura',
      camSub: '24 Hours · Bapupura, Ta-Mansa, Dis-Gandhinagar, Gujarat',
      infoTitle: 'Temple & Event Timings',
      t1l: 'Weekly Puja', t1v: 'Every Monday', t1n: 'Shri Nilkanth Mahadev Mandir',
      t2l: 'Evening Dhun', t2v: 'Evening', t2n: '।। Om Namah Shivay ।।',
      t3l: 'Maha Mahotsav', t3v: '22–25 Oct 2026', t3n: '4 Days of Devotion',
      t4l: 'Address', t4v: 'Bapupura, Ta-Mansa', t4n: 'Dis-Gandhinagar, Gujarat',
    },
    albums: {
      eye: 'Event Memories', title: 'Photo Albums',
      sub: 'Every celebration preserved. Every moment remembered.',
      upcoming: 'Upcoming', recent: 'Recent', past: 'Past',
      photos: (n: number) => n === 0 ? 'No photos yet' : `${n} Photos`,
      view: 'View Album', empty: 'Coming soon',
      adminNote: 'Albums are created by the organizing committee.',
    },
    upload: {
      eye: 'Community', title: 'Share a Memory',
      sub: 'Upload your photos from village events. All photos are reviewed before going public.',
      nameL: 'Your Name', nameP: 'Enter your name',
      phoneL: 'Mobile Number (optional)', phoneP: '9876543210',
      albumL: 'Select Album', albumP: 'Choose an album',
      captionL: 'Caption (optional)', captionP: 'Describe this moment…',
      drop: 'Tap to select photos', dropSub: 'JPG, PNG · up to 10 MB each',
      submit: 'Submit for Review', submitting: 'Submitting…',
      successTitle: 'Submitted!',
      successMsg: 'Your photo has been sent for review. It will appear publicly once approved. Thank you for contributing.',
      again: 'Submit Another',
      notice: '।। Every photo is reviewed before going live ।।',
      files: (n: number) => `${n} file${n !== 1 ? 's' : ''} selected`,
    },
    about: {
      eye: 'Our Village', title: 'Bapupura',
      sub: 'Mansa Taluka · Gandhinagar District · Gujarat',
      d1: 'Bapupura is a village in Mansa Taluka, Gandhinagar District, Gujarat. Rooted in faith and bound by community, it is a place where tradition lives not in memory alone but in daily practice — in the Monday pujas, the seasonal festivals, and the bonds that form around the Shri Nilkanth Mahadev Mandir.',
      d2: 'The village\'s organizing spirit is embodied in Shri Bapupura Yuva Ekta Manch and Shri Shivshakti Ras Mandal — youth-led bodies that plan, coordinate and celebrate every event, keeping the devotional fire burning across generations.',
      committeeTitle: 'Organizing Committee',
      committeeSub: 'Shri Nilkanth Mahadev Maha Mahotsav 2026',
      pramukh: 'Pramukh', mantri: 'Mantri', pravakta: 'Pravakta', sanyojak: 'Sanyojak',
      pramukhName: 'Kanjibhai Chaudhary',
      mantriName: 'Madhubhai Chaudhary',
      pravaktaName: 'Prof. Praveen F. Chaudhary',
      sanyojakName: 'Shri Bapupura Yuva Ekta Manch',
      members: 'Stage Service',
      membersList: ['Dr. Jayesh N. Chaudhary', 'Cho. Jagadishbhai Mangalabhai', 'Cho. Atulbhai Jivabhai', 'Cho. Hiteshbhai Lavjibhai (Dhoni)', 'Cho. Dasarathbhai Gandabhai', 'Cho. Rajeshbhai Ambalalbhai', 'Prajapati Vipulbhai Arvindbhai'],
    },
    footer: {
      mantra: '।। Har Har Mahadev ।।',
      event: 'Shri Nilkanth Mahadev Maha Mahotsav 2026',
      address: 'Bapupura, Ta-Mansa, Dis-Gandhinagar, Gujarat',
      organizer: 'Shri Bapupura Yuva Ekta Manch',
    },
  },
  gu: {
    nav: { home: 'ઘર', darshan: 'લાઇવ દર્શન', albums: 'આલ્બમ', upload: 'અપલોડ', about: 'વિશે', lang: 'English' },
    hero: {
      organizer: 'શ્રી શિવશક્તિ રાસ મંડળ & શ્રી બાપુપૂરા યુવા એકતા મંચ',
      eventName: 'શ્રી નીલકંઠ મહાદેવ\nમહા મહોત્સવ',
      dates: '૨૨ – ૨૫ ઓક્ટોબર ૨૦૨૬',
      location: 'શ્રી નીલકંઠ મહાદેવ મંદિર, બાપુપૂરા',
      address: 'બાપુપૂરા, તા-માણસા, જિ-ગાંધીનગર, ગુજરાત',
      cta1: 'આલ્બમ જુઓ', cta2: 'લાઇવ દર્શન',
      mantra: '।। ॐ નમઃ શિવાય ।।',
      countdownLabel: 'મહોત્સવ શરૂ થવામાં',
      D: 'દિવસ', H: 'કલાક', M: 'મિનિટ', S: 'સેકન્ડ',
    },
    darshan: {
      eye: 'પવિત્ર લાઇવ',
      title: 'શ્રી નીલકંઠ મહાદેવ — લાઇવ દર્શન',
      sub: 'ગમે ત્યાંથી, ગમે ત્યારે — મંદિરના સીધા દર્શન.',
      camLabel: '🔴 શ્રી નીલકંઠ મહાદેવ મંદિર — Live · બાપુપૂરા',
      camSub: '૨૪ કલાક · બાપુપૂરા, તા-માણસા, જિ-ગાંધીનગર, ગુજરાત',
      infoTitle: 'મંદિર અને ઉત્સવ સમય',
      t1l: 'સાપ્તાહિક પૂજા', t1v: 'દર સોમવારે', t1n: 'શ્રી નીલકંઠ મહાદેવ મંદિર',
      t2l: 'સાંજની ધૂન', t2v: 'સાંજે', t2n: '।। ॐ નમઃ શિવાય ।।',
      t3l: 'મહા મહોત્સવ', t3v: '૨૨–૨૫ ઓક્ટો ૨૦૨૬', t3n: '૪ દિવસ ભક્તિ',
      t4l: 'સ્થળ', t4v: 'બાપુપૂરા, તા-માણસા', t4n: 'જિ-ગાંધીનગર, ગુજરાત',
    },
    albums: {
      eye: 'ઉત્સવ સ્મૃતિ', title: 'ફોટો આલ્બમ',
      sub: 'દરેક ઉત્સવ સચવાયેલો. દરેક ક્ષણ અમર.',
      upcoming: 'આગામી', recent: 'તાજેતર', past: 'ભૂતકાળ',
      photos: (n: number) => n === 0 ? 'ફોટો નથી' : `${n} ફોટો`,
      view: 'આલ્બમ જુઓ', empty: 'ટૂંક સમયમાં',
      adminNote: 'આલ્બમ આયોજન સમિતી દ્વારા બને.',
    },
    upload: {
      eye: 'સમુદાય', title: 'સ્મૃતિ શેર કરો',
      sub: 'ગ્રામ ઉત્સવોના ફોટો અપલોડ કરો. મંજૂરી બાદ ફોટો જાહેર થાય.',
      nameL: 'આપનું નામ', nameP: 'નામ દાખલ કરો',
      phoneL: 'મોબાઇલ (વૈકલ્પિક)', phoneP: '9876543210',
      albumL: 'આલ્બમ પસંદ', albumP: 'આલ્બમ પસંદ કરો',
      captionL: 'કેપ્શન (વૈકલ્પિક)', captionP: 'આ ક્ષણ વર્ણવો…',
      drop: 'ફોટો ટેપ કરો', dropSub: 'JPG, PNG · 10 MB',
      submit: 'સમીક્ષાને', submitting: 'રાહો…',
      successTitle: 'સફળ!',
      successMsg: 'આપનો ફોટો મોકલાયો. મંજૂરીની ઇંતેજારી.',
      again: 'બીજો ફોટો',
      notice: '।। દરેક ફોટો સમીક્ષા કરાય ।।',
      files: (n: number) => `${n} ફાઇલ`,
    },
    about: {
      eye: 'આપણું ગામ', title: 'બાપુપૂરા',
      sub: 'માણસા · ગાંધીનગર · ગુજરાત',
      d1: 'બાપુપૂરા ગુજરાતના ગાંધીનગર જિલ્લાના માણસા તાલુકામાં આવેલું ગામ છે. ભક્તિ અને સમુદાય ભાવનામાં ઓતપ્રોત, અહીં પરંપરા ફક્ત સ્મૃતિમાં નહીં — પ્રત્યક્ષ જીવનમાં જીવે છે.',
      d2: 'ગામની ભાવના શ્રી બાપુપૂરા યુવા એકતા મંચ અને શ્રી શિવશક્તિ રાસ મંડળમાં જીવંત છે.',
      committeeTitle: 'મુખ્ય આયોજન કમિટી',
      committeeSub: 'શ્રી નીલકંઠ મહાદેવ મહા મહોત્સવ ૨૦૨૬',
      pramukh: 'પ્રમુખશ્રી', mantri: 'મંત્રીશ્રી', pravakta: 'પ્રવક્તા', sanyojak: 'સંયોજક',
      pramukhName: 'Kanjibhai Chaudhary',
      mantriName: 'Madhubhai Chaudhary',
      pravaktaName: 'Prof. Praveen F. Chaudhary',
      sanyojakName: 'શ્રી બાપુપૂરા યુવા એકતા મંચ',
      members: 'સ્ટેજ સેવા',
      membersList: ['Dr. Jayesh N. Chaudhary', 'Cho. Jagadishbhai Mangalabhai', 'Cho. Atulbhai Jivabhai', 'Cho. Hiteshbhai Lavjibhai (Dhoni)', 'Cho. Dasarathbhai Gandabhai', 'Cho. Rajeshbhai Ambalalbhai', 'Prajapati Vipulbhai Arvindbhai'],
    },
    footer: {
      mantra: '।। હર હર મહાદેવ ।।',
      event: 'શ્રી નીલકંઠ મહાદેવ મહા મહોત્સવ ૨૦૨૬',
      address: 'બાપુપૂરા, તા-માણસા, જિ-ગાંધીનગર, ગુજરાત',
      organizer: 'શ્રી બાપુપૂરા યુવા એકતા મંચ',
    },
  },
} as const;

// ─── ALBUMS DATA ─────────────────────────────────────────────────────────────
const ALBUMS = [
  { id: 1, en: 'Shri Nilkanth Mahadev Maha Mahotsav', gu: 'શ્રી નીલકંઠ મહાદેવ મહા મહોત્સવ', dateEn: 'October 22–25, 2026', dateGu: '૨૨–૨૫ ઓક્ટોબર ૨૦૨૬', status: 'upcoming' as const, count: 0 },
  { id: 2, en: 'Uchhaamani Celebration', gu: 'ભવ્ય ઉછામણી', dateEn: 'May 30, 2026', dateGu: '૩૦ મે, ૨૦૨૬', status: 'recent' as const, count: 24 },
  { id: 3, en: 'Committee Meeting & Planning', gu: 'કમિટી મિટિંગ', dateEn: 'June 2026', dateGu: 'જૂન ૨૦૨૬', status: 'recent' as const, count: 12 },
];

// ─── COUNTDOWN ───────────────────────────────────────────────────────────────
function useCountdown() {
  const calc = () => { const d = new Date('2026-10-22T00:00:00+05:30').getTime() - Date.now(); return d > 0 ? { d: Math.floor(d/86400000), h: Math.floor((d%86400000)/3600000), m: Math.floor((d%3600000)/60000), s: Math.floor((d%60000)/1000) } : { d:0,h:0,m:0,s:0 }; };
  const [t, setT] = useState(calc);
  useEffect(() => { const id = setInterval(() => setT(calc()), 1000); return () => clearInterval(id); }, []);
  return t;
}

// ─── DIVIDER ─────────────────────────────────────────────────────────────────
function Divider() {
  return <div style={{ display:'flex', alignItems:'center', gap:14, padding:'2px 28px', background: C.bg }}><div style={{ flex:1, height:1, background:`linear-gradient(to right,transparent,${C.bd},transparent)` }}/><span style={{ color:C.gold, opacity:.5, fontSize:13 }}>✦</span><div style={{ flex:1, height:1, background:`linear-gradient(to right,transparent,${C.bd},transparent)` }}/></div>;
}

// ─── SECTION HEADER ──────────────────────────────────────────────────────────
function SHead({ eye, title, sub, isGu, center = true }: { eye:string; title:string; sub?:string; isGu:boolean; center?:boolean }) {
  return <div style={{ textAlign: center ? 'center' : 'left', marginBottom: 28 }}>
    <p style={{ fontSize:9, letterSpacing:4, textTransform:'uppercase', color:C.sf, fontFamily:"'Inter',sans-serif", marginBottom:8, fontWeight:600 }}>{eye}</p>
    <h2 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1.5rem,4vw,2.2rem)' : 'clamp(1.8rem,4vw,2.6rem)', fontWeight: isGu ? 700 : 600, color: C.maroon, marginBottom: sub ? 6 : 0, lineHeight:1.15 }}>{title}</h2>
    {sub && <p style={{ fontSize:12, color:C.tx2, lineHeight:1.7 }}>{sub}</p>}
  </div>;
}

// ─── INPUT STYLES ────────────────────────────────────────────────────────────
const inp: React.CSSProperties = { width:'100%', padding:'10px 14px', background:C.white, border:`1px solid ${C.bd}`, color:C.tx, fontSize:'0.875rem', outline:'none', boxSizing:'border-box', fontFamily:"'Inter',sans-serif", transition:'border-color 200ms' };
const lbl: React.CSSProperties = { display:'block', fontSize:9, letterSpacing:'0.2em', textTransform:'uppercase', color:C.tx3, fontFamily:"'Inter',sans-serif", marginBottom:6 };
const onFocus = (e: React.FocusEvent) => { (e.target as HTMLElement).style.borderColor = C.maroon; };
const onBlur = (e: React.FocusEvent) => { (e.target as HTMLElement).style.borderColor = C.bd; };

// ─── NAVBAR ──────────────────────────────────────────────────────────────────
function Navbar({ lang, page, go, toggleLang, t }: { lang:Lang; page:Page; go:(p:Page)=>void; toggleLang:()=>void; t:typeof T['en']['nav'] }) {
  const [mob, setMob] = useState(false);
  const isGu = lang === 'gu';
  const items: {key:Page; label:string}[] = [
    { key:'home', label:t.home }, { key:'darshan', label:t.darshan },
    { key:'albums', label:t.albums }, { key:'upload', label:t.upload }, { key:'about', label:t.about },
  ];
  const go2 = (p:Page) => { go(p); setMob(false); };
  const activeStyle = (k:Page): React.CSSProperties => ({ color: page===k ? C.maroon : C.tx3, borderBottom: page===k ? `1.5px solid ${C.maroon}` : '1.5px solid transparent', fontWeight: page===k ? 600 : 400 });
  return (
    <nav style={{ position:'fixed', top:0, left:0, right:0, zIndex:50, background:'rgba(255,255,255,0.97)', backdropFilter:'blur(12px)', borderBottom:`1px solid ${C.bd2}`, boxShadow:`0 1px 12px rgba(181,120,10,0.07)` }}>
      <div style={{ maxWidth:1200, margin:'0 auto', padding:'0 24px', height:64, display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <button onClick={() => go2('home')} style={{ background:'none', border:'none', cursor:'pointer', display:'flex', alignItems:'center', gap:10, padding:0 }}>
          <span style={{ fontFamily:'serif', fontSize:'1.6rem', color:C.maroon, lineHeight:1 }}>ॐ</span>
          <div>
            <div style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize:'1.05rem', fontWeight:700, color:C.maroon, lineHeight:1.1 }}>{isGu ? 'બાપુપૂરા' : 'Bapupura'}</div>
            <div style={{ fontSize:'0.58rem', color:C.tx3, letterSpacing:'0.18em', textTransform:'uppercase', fontFamily:"'Inter',sans-serif" }}>Ta-Mansa · Gandhinagar</div>
          </div>
        </button>
        {/* Desktop */}
        <div style={{ display:'flex', alignItems:'center', gap:4 }}>
          {items.map(({key,label}) => (
            <button key={key} onClick={() => go2(key)} style={{ ...activeStyle(key), background:'none', border:'none', borderBottom: activeStyle(key).borderBottom, padding:'6px 12px', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.85rem' : '0.72rem', letterSpacing: isGu ? 0 : '0.1em', textTransform: isGu ? 'none' : 'uppercase', cursor:'pointer', transition:'color 200ms' }}>{label}</button>
          ))}
          <button onClick={toggleLang} style={{ marginLeft:8, padding:'5px 13px', background:C.maroonL, border:`1px solid rgba(122,21,21,0.2)`, color:C.maroon, fontSize:'0.72rem', cursor:'pointer', fontFamily: isGu ? "'Inter',sans-serif" : "'Noto Sans Gujarati',sans-serif" }}>{t.lang}</button>
        </div>
      </div>
      {/* Mobile menu */}
      {mob && (
        <div style={{ background:'rgba(255,255,255,0.98)', borderTop:`1px solid ${C.bd2}`, padding:'16px 24px 24px' }}>
          {items.map(({key,label}) => <button key={key} onClick={()=>go2(key)} style={{ display:'block', width:'100%', textAlign:'left', background:'none', border:'none', borderBottom:`1px solid ${C.bd2}`, padding:'12px 0', fontSize:'1rem', color:page===key?C.maroon:C.tx, cursor:'pointer', fontFamily:isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{label}</button>)}
          <button onClick={()=>{toggleLang();setMob(false);}} style={{ marginTop:16, padding:'8px 20px', background:C.maroonL, border:`1px solid rgba(122,21,21,0.2)`, color:C.maroon, fontSize:'0.85rem', cursor:'pointer' }}>{t.lang}</button>
        </div>
      )}
    </nav>
  );
}

// ─── HOME PAGE ───────────────────────────────────────────────────────────────
function HomePage({ lang, t, go }: { lang:Lang; t:typeof T['en']; go:(p:Page)=>void }) {
  const isGu = lang === 'gu';
  const cd = useCountdown();
  const h = t.hero;
  const pad = (n:number) => String(n).padStart(2,'0');
  return (
    <div>
      {/* Hero */}
      <section style={{ minHeight:'100svh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', textAlign:'center', padding:'clamp(88px,12vw,130px) clamp(20px,5vw,60px) clamp(60px,8vw,100px)', background:`linear-gradient(180deg, ${C.white} 0%, ${C.bg} 100%)`, position:'relative', overflow:'hidden' }}>
        {/* Subtle pattern */}
        <div style={{ position:'absolute', inset:0, backgroundImage:`radial-gradient(circle at 20% 20%, rgba(181,120,10,0.04) 0%, transparent 50%), radial-gradient(circle at 80% 80%, rgba(122,21,21,0.03) 0%, transparent 50%)`, pointerEvents:'none' }}/>
        {/* Vertical line top */}
        <div style={{ width:1, height:40, background:`linear-gradient(to bottom, transparent, ${C.gold})`, marginBottom:22 }}/>
        {/* OM */}
        <div style={{ fontSize:'3.2rem', color:C.maroon, lineHeight:1, marginBottom:10, opacity:.85 }}>ॐ</div>
        {/* Organizer */}
        <p style={{ fontSize:9, letterSpacing:4, textTransform:'uppercase', color:C.sf, fontFamily:"'Inter',sans-serif", marginBottom:16, fontWeight:500, maxWidth:500 }}>{h.organizer}</p>
        {/* Event name */}
        <h1 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(2rem,8vw,4.5rem)' : 'clamp(2.5rem,9vw,5.5rem)', fontWeight: isGu ? 700 : 600, color:C.maroon, lineHeight:1.1, marginBottom:14, whiteSpace:'pre-line' }}>{h.eventName}</h1>
        {/* Dates badge */}
        <div style={{ display:'inline-block', background:C.maroon, color:'#fff', fontSize:13, fontWeight:600, padding:'8px 24px', letterSpacing:1, marginBottom:10 }}>{h.dates}</div>
        {/* Location */}
        <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 13 : 15, fontStyle: isGu ? 'normal' : 'italic', color:C.gold, marginBottom:4 }}>{h.location}</p>
        <p style={{ fontSize:9, color:C.tx3, letterSpacing:3, textTransform:'uppercase', marginBottom:28 }}>{h.address}</p>
        {/* Ornament */}
        <p style={{ color:C.gold, opacity:.35, letterSpacing:10, fontSize:11, marginBottom:26 }}>— ✦ —</p>
        {/* Countdown label */}
        <p style={{ fontSize:9, color:C.tx3, letterSpacing:3, textTransform:'uppercase', fontFamily:"'Inter',sans-serif", marginBottom:12 }}>{h.countdownLabel}</p>
        {/* Countdown */}
        <div style={{ display:'inline-flex', gap:3, marginBottom:10 }}>
          {[{v:cd.d,l:h.D},{v:cd.h,l:h.H},{v:cd.m,l:h.M},{v:cd.s,l:h.S}].map(({v,l}) => (
            <div key={l} style={{ background:C.maroon, padding:'12px 16px', textAlign:'center', minWidth:58 }}>
              <span style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:26, fontWeight:600, color:'#fff', display:'block', lineHeight:1 }}>{l===h.D?v:pad(v)}</span>
              <span style={{ fontSize:7, color:'rgba(255,255,255,0.6)', letterSpacing:2, textTransform:'uppercase', display:'block', marginTop:3 }}>{l}</span>
            </div>
          ))}
        </div>
        {/* CTAs */}
        <div style={{ display:'flex', gap:12, justifyContent:'center', flexWrap:'wrap', marginTop:18 }}>
          <button onClick={() => go('albums')} style={{ padding:'11px 28px', background:C.maroon, border:'none', color:'#fff', fontSize:10, fontWeight:600, letterSpacing:2, textTransform:'uppercase', cursor:'pointer', fontFamily:"'Inter',sans-serif", transition:'opacity 0.2s' }} onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.opacity='0.85'}} onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.opacity='1'}}>{h.cta1}</button>
          <button onClick={() => go('darshan')} style={{ padding:'11px 28px', background:'transparent', border:`1px solid rgba(122,21,21,0.3)`, color:C.maroon, fontSize:10, fontWeight:500, letterSpacing:2, textTransform:'uppercase', cursor:'pointer', fontFamily:"'Inter',sans-serif" }}>{h.cta2}</button>
        </div>
        {/* Mantra */}
        <p style={{ marginTop:36, fontFamily:"'Cormorant Garamond',serif", fontSize:'clamp(1rem,2.5vw,1.2rem)', color:`rgba(122,21,21,0.5)`, fontStyle:'italic', letterSpacing:'0.1em' }}>{h.mantra}</p>
        {/* Scroll line */}
        <div style={{ position:'absolute', bottom:24, left:'50%', transform:'translateX(-50%)' }}>
          <div style={{ width:1, height:36, background:`linear-gradient(to bottom,${C.gold},transparent)`, opacity:.5 }}/>
        </div>
      </section>
      <Divider/>
      {/* Event info strip */}
      <section style={{ background:C.white, padding:'36px 28px' }}>
        <SHead eye={lang==='en'?'Festival Information':'ઉત્સવ માહિતી'} title={lang==='en'?'About The Event':'ઉત્સવ વિશે'} isGu={isGu}/>
        <div style={{ maxWidth:800, margin:'0 auto', display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:1, background:C.bd }}>
          {[
            { l: lang==='en'?'Dates':'તારીખ', v: lang==='en'?'22–25 October 2026':'૨૨–૨૫ ઓક્ટોબર ૨૦૨૬', n: lang==='en'?'4 Days':'૪ દિવસ' },
            { l: lang==='en'?'Evening Dhun':'સાંજની ધૂન', v: lang==='en'?'Every Monday':'દર સોમવારે', n: '।। ॐ નમઃ શિવાય ।।' },
            { l: lang==='en'?'Location':'સ્થળ', v: lang==='en'?'Nilkanth Mandir':'નીલકંઠ મંદિર', n: lang==='en'?'Bapupura, Ta-Mansa':'બાપુપૂરા, તા-માણસા' },
            { l: lang==='en'?'Organizer':'આયોજક', v: lang==='en'?'Yuva Ekta Manch':'યુવા એકતા મંચ', n: 'Bapupura' },
          ].map(({l,v,n}) => (
            <div key={l} style={{ background:C.bg2, padding:'16px 18px' }}>
              <div style={{ fontSize:8, color:C.sf, letterSpacing:2, textTransform:'uppercase', marginBottom:4, fontWeight:600, fontFamily:"'Inter',sans-serif" }}>{l}</div>
              <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:16, color:C.maroon, fontWeight:700 }}>{v}</div>
              <div style={{ fontSize:9, color:C.tx3, marginTop:2, fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{n}</div>
            </div>
          ))}
        </div>
      </section>
      <Divider/>
      {/* Albums preview */}
      <section style={{ background:C.bg, padding:'36px 28px' }}>
        <SHead eye={t.albums.eye} title={t.albums.title} sub={t.albums.sub} isGu={isGu}/>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(min(100%,280px),1fr))', gap:16, maxWidth:900, margin:'0 auto' }}>
          {ALBUMS.slice(0,2).map(a => {
            const sc = a.status==='upcoming' ? {bg:'rgba(181,120,10,0.08)',tx:C.gold,bd:C.bd} : {bg:'rgba(14,122,48,0.06)',tx:'#0E7A30',bd:'rgba(14,122,48,0.2)'};
            return (
              <div key={a.id} style={{ background:C.white, border:`1px solid ${C.bd}`, padding:18, cursor:'pointer', transition:'transform 0.2s, box-shadow 0.2s' }}
                onMouseEnter={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(-2px)';(e.currentTarget as HTMLElement).style.boxShadow=`0 4px 20px rgba(181,120,10,0.12)`;}}
                onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(0)';(e.currentTarget as HTMLElement).style.boxShadow='none';}}>
                <span style={{ fontSize:7, letterSpacing:2, textTransform:'uppercase', padding:'2px 8px', background:sc.bg, border:`1px solid ${sc.bd}`, color:sc.tx, fontFamily:"'Inter',sans-serif" }}>{t.albums[a.status]}</span>
                <p style={{ fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Cormorant Garamond',serif", fontSize: isGu?14:16, fontWeight: isGu?700:600, color:C.tx, margin:'10px 0 4px' }}>{isGu?a.gu:a.en}</p>
                <p style={{ fontSize:9, color:C.tx3 }}>{isGu?a.dateGu:a.dateEn}</p>
              </div>
            );
          })}
        </div>
        <div style={{ textAlign:'center', marginTop:20 }}>
          <button onClick={()=>go('albums')} style={{ padding:'10px 24px', background:'transparent', border:`1px solid ${C.bd}`, color:C.gold, fontSize:10, letterSpacing:2, textTransform:'uppercase', cursor:'pointer', fontFamily:"'Inter',sans-serif" }}>{lang==='en'?'View All Albums':'બધા આલ્બમ'}</button>
        </div>
      </section>
    </div>
  );
}

// ─── DARSHAN PAGE ─────────────────────────────────────────────────────────────
function DarshanPage({ lang, t }: { lang:Lang; t:typeof T['en']['darshan'] }) {
  const isGu = lang === 'gu';
  return (
    <div style={{ paddingTop:64, background:C.bg }}>
      <section style={{ padding:'48px 28px', background:C.white }}>
        <div style={{ maxWidth:900, margin:'0 auto' }}>
          <div style={{ display:'inline-flex', alignItems:'center', gap:6, background:'rgba(212,43,43,0.07)', border:'1px solid rgba(212,43,43,0.2)', padding:'3px 12px', marginBottom:14 }}>
            <span style={{ width:7, height:7, borderRadius:'50%', background:'#D42B2B', display:'inline-block', animation:'liveP 1.5s infinite' }}/>
            <style>{`@keyframes liveP{0%,100%{opacity:1}50%{opacity:0.3}}`}</style>
            <span style={{ fontSize:9, color:'#D42B2B', letterSpacing:2, textTransform:'uppercase', fontWeight:600 }}>{t.eye}</span>
          </div>
          <h1 style={{ fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Cormorant Garamond',serif", fontSize: isGu?'clamp(1.4rem,4vw,2rem)':'clamp(1.6rem,4vw,2.4rem)', fontWeight: isGu?700:600, color:C.maroon, marginBottom:6 }}>{t.title}</h1>
          <p style={{ fontSize:12, color:C.tx2, marginBottom:20 }}>{t.sub}</p>
          {/* YouTube embed */}
          <div style={{ border:`1px solid ${C.bd}`, overflow:'hidden', borderRadius:0 }}>
            <div style={{ position:'relative', width:'100%', paddingTop:'56.25%' }}>
              <iframe src="https://www.youtube.com/embed/GrZmqQBPHxE?rel=0" allowFullScreen allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" style={{ position:'absolute', inset:0, width:'100%', height:'100%', border:'none', display:'block' }}/>
            </div>
            <div style={{ background:C.maroon, padding:'10px 16px' }}>
              <div style={{ fontSize:11, color:'#fff', fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{t.camLabel}</div>
              <div style={{ fontSize:9, color:'rgba(255,255,255,0.5)', marginTop:2 }}>{t.camSub}</div>
            </div>
          </div>
          {/* Timings grid */}
          <h3 style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:20, color:C.maroon, margin:'28px 0 14px' }}>{t.infoTitle}</h3>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:1, background:C.bd }}>
            {[{l:t.t1l,v:t.t1v,n:t.t1n},{l:t.t2l,v:t.t2v,n:t.t2n},{l:t.t3l,v:t.t3v,n:t.t3n},{l:t.t4l,v:t.t4v,n:t.t4n}].map(({l,v,n}) => (
              <div key={l} style={{ background:C.bg2, padding:'14px 16px' }}>
                <div style={{ fontSize:8, color:C.sf, letterSpacing:2, textTransform:'uppercase', marginBottom:4, fontWeight:600, fontFamily:"'Inter',sans-serif" }}>{l}</div>
                <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:16, color:C.maroon, fontWeight:700 }}>{v}</div>
                <div style={{ fontSize:9, color:C.tx3, marginTop:2 }}>{n}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── ALBUMS PAGE ──────────────────────────────────────────────────────────────
function AlbumsPage({ lang, t }: { lang:Lang; t:typeof T['en']['albums'] }) {
  const isGu = lang === 'gu';
  return (
    <div style={{ paddingTop:64, background:C.bg, minHeight:'100svh' }}>
      <section style={{ padding:'48px 28px' }}>
        <div style={{ maxWidth:1000, margin:'0 auto' }}>
          <SHead eye={t.eye} title={t.title} sub={t.sub} isGu={isGu}/>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(min(100%,300px),1fr))', gap:20 }}>
            {ALBUMS.map(a => {
              const sc = a.status==='upcoming' ? {bg:'rgba(181,120,10,0.08)',tx:C.gold,bd:C.bd} : {bg:'rgba(14,122,48,0.06)',tx:'#0E7A30',bd:'rgba(14,122,48,0.2)'};
              return (
                <div key={a.id} style={{ background:C.white, border:`1px solid ${C.bd}`, transition:'transform 0.2s, box-shadow 0.2s', cursor:a.status!=='upcoming'?'pointer':'default' }}
                  onMouseEnter={e=>{if(a.status!=='upcoming'){(e.currentTarget as HTMLElement).style.transform='translateY(-2px)';(e.currentTarget as HTMLElement).style.boxShadow=`0 4px 20px rgba(181,120,10,0.12)`;}}}
                  onMouseLeave={e=>{(e.currentTarget as HTMLElement).style.transform='translateY(0)';(e.currentTarget as HTMLElement).style.boxShadow='none';}}>
                  <div style={{ height:120, background: a.status==='upcoming'?`linear-gradient(135deg,${C.maroon}22,${C.maroon}11)`:C.bg2, display:'flex', alignItems:'center', justifyContent:'center' }}>
                    <span style={{ fontSize:'2.5rem', opacity:.2, fontFamily:'serif', color:C.maroon }}>ॐ</span>
                  </div>
                  <div style={{ padding:'16px 18px 20px' }}>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
                      <span style={{ fontSize:7, letterSpacing:2, textTransform:'uppercase', padding:'2px 8px', background:sc.bg, border:`1px solid ${sc.bd}`, color:sc.tx, fontFamily:"'Inter',sans-serif" }}>{t[a.status]}</span>
                      <span style={{ fontSize:9, color:C.tx3 }}>{t.photos(a.count)}</span>
                    </div>
                    <p style={{ fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Cormorant Garamond',serif", fontSize: isGu?14:16, fontWeight: isGu?700:600, color:C.tx, marginBottom:4, lineHeight:1.3 }}>{isGu?a.gu:a.en}</p>
                    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                      <span style={{ fontSize:9, color:C.tx3, fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{isGu?a.dateGu:a.dateEn}</span>
                      {a.status!=='upcoming' && <span style={{ fontSize:9, color:C.gold, letterSpacing:1, textTransform:'uppercase', fontFamily:"'Inter',sans-serif" }}>{t.view} →</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <p style={{ textAlign:'center', marginTop:28, fontSize:9, color:'rgba(154,138,118,0.5)', letterSpacing:2, fontFamily:"'Inter',sans-serif" }}>{t.adminNote}</p>
        </div>
      </section>
    </div>
  );
}

// ─── UPLOAD PAGE ──────────────────────────────────────────────────────────────
function UploadPage({ lang, t }: { lang:Lang; t:typeof T['en']['upload'] }) {
  const isGu = lang === 'gu';
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [album, setAlbum] = useState('');
  const [caption, setCaption] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [drag, setDrag] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const albumOpts = lang==='en' ? ['Nilkanth Mahadev Mahotsav — Oct 2026','Uchhaamani — May 2026','Committee Meeting — June 2026'] : ['નીલકંઠ મહોત્સવ — ઓક્ટો ૨૦૨૬','ઉછામણી — મે ૨૦૨૬','કમિટી — જૂન ૨૦૨૬'];
  const guInp: React.CSSProperties = isGu ? { fontFamily:"'Noto Sans Gujarati',sans-serif", fontSize:'0.9rem' } : {};
  const submit = (e: React.FormEvent) => { e.preventDefault(); if(!name.trim()||files.length===0) return; setSubmitting(true); setTimeout(()=>{setSubmitting(false);setSubmitted(true);},1800); };
  return (
    <div style={{ paddingTop:64, background:C.bg, minHeight:'100svh' }}>
      <section style={{ padding:'48px 28px' }}>
        <div style={{ maxWidth:600, margin:'0 auto' }}>
          <SHead eye={t.eye} title={t.title} sub={t.sub} isGu={isGu}/>
          {submitted ? (
            <div style={{ textAlign:'center', padding:'52px 32px', background:C.white, border:`1px solid ${C.bd}` }}>
              <svg width="48" height="48" viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="22" stroke={C.maroon} strokeWidth="1.4" opacity="0.4"/><path d="M14 24l7 7 13-14" stroke={C.maroon} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
              <h3 style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:'clamp(1.3rem,4vw,1.8rem)', color:C.maroon, margin:'16px 0 10px' }}>{t.successTitle}</h3>
              <p style={{ fontSize:'0.875rem', color:C.tx2, lineHeight:1.7, maxWidth:380, margin:'0 auto 24px', fontFamily:isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{t.successMsg}</p>
              <button onClick={()=>{setName('');setPhone('');setAlbum('');setCaption('');setFiles([]);setSubmitted(false);}} style={{ padding:'10px 24px', background:C.maroonL, border:`1px solid rgba(122,21,21,0.2)`, color:C.maroon, cursor:'pointer', fontSize:11, fontFamily:"'Inter',sans-serif", letterSpacing:2, textTransform:'uppercase' }}>{t.again}</button>
            </div>
          ) : (
            <form onSubmit={submit} style={{ display:'flex', flexDirection:'column', gap:20 }}>
              <div><label style={lbl}>{t.nameL}</label><input required value={name} onChange={e=>setName(e.target.value)} placeholder={t.nameP} style={{...inp,...guInp}} onFocus={onFocus} onBlur={onBlur}/></div>
              <div><label style={lbl}>{t.phoneL}</label><input type="tel" value={phone} onChange={e=>setPhone(e.target.value)} placeholder={t.phoneP} style={{...inp,...guInp}} onFocus={onFocus} onBlur={onBlur}/></div>
              <div>
                <label style={lbl}>{t.albumL}</label>
                <select value={album} onChange={e=>setAlbum(e.target.value)} style={{...inp,...guInp, appearance:'none', cursor:'pointer'}} onFocus={onFocus} onBlur={onBlur}>
                  <option value="" disabled>{t.albumP}</option>
                  {albumOpts.map((o,i)=><option key={i} value={o}>{o}</option>)}
                </select>
              </div>
              <div><label style={lbl}>{t.captionL}</label><textarea value={caption} onChange={e=>setCaption(e.target.value)} placeholder={t.captionP} rows={3} style={{...inp,...guInp, resize:'vertical', minHeight:76}} onFocus={onFocus} onBlur={onBlur}/></div>
              <div>
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple style={{display:'none'}} onChange={e=>e.target.files&&setFiles(Array.from(e.target.files))}/>
                <div onClick={()=>fileRef.current?.click()} onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);e.dataTransfer.files&&setFiles(Array.from(e.dataTransfer.files));}}
                  style={{ padding:'32px 20px', border:`1px dashed ${drag||files.length>0?C.maroon:C.bd}`, background: drag?C.maroonL:C.white, cursor:'pointer', textAlign:'center', transition:'all 200ms' }}>
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" style={{display:'block',margin:'0 auto 8px'}}><path d="M14 4v16M14 4l-5 5M14 4l5 5" stroke={C.maroon} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" opacity=".65"/><path d="M4 22v1.5A1.5 1.5 0 005.5 25h17a1.5 1.5 0 001.5-1.5V22" stroke={C.maroon} strokeWidth="1.2" strokeLinecap="round" opacity=".4"/></svg>
                  {files.length>0 ? <p style={{ fontSize:13, color:C.maroon }}>{t.files(files.length)}</p> : <><p style={{ fontSize:13, color:C.tx2, fontFamily:isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{t.drop}</p><p style={{ fontSize:9, color:C.tx3, marginTop:4 }}>{t.dropSub}</p></>}
                </div>
              </div>
              <button type="submit" disabled={submitting||!name.trim()||files.length===0} style={{ padding:'13px 32px', background: submitting||!name.trim()||files.length===0 ? 'rgba(122,21,21,0.3)' : C.maroon, border:'none', color:'#fff', fontSize:11, fontWeight:600, letterSpacing:2, textTransform:'uppercase', cursor:submitting||!name.trim()||files.length===0?'not-allowed':'pointer', fontFamily:"'Inter',sans-serif", transition:'background 200ms' }}>{submitting?t.submitting:t.submit}</button>
              <p style={{ textAlign:'center', fontSize:10, color:`rgba(181,120,10,0.45)`, fontFamily:"'Cormorant Garamond',serif", fontStyle:'italic' }}>{t.notice}</p>
            </form>
          )}
        </div>
      </section>
    </div>
  );
}

// ─── ABOUT PAGE ───────────────────────────────────────────────────────────────
function AboutPage({ lang, t }: { lang:Lang; t:typeof T['en']['about'] }) {
  const isGu = lang === 'gu';
  const roles = [{r:t.pramukh,n:t.pramukhName},{r:t.mantri,n:t.mantriName},{r:t.pravakta,n:t.pravaktaName},{r:t.sanyojak,n:t.sanyojakName}];
  return (
    <div style={{ paddingTop:64, background:C.bg, minHeight:'100svh' }}>
      <section style={{ padding:'48px 28px', background:C.white }}>
        <div style={{ maxWidth:800, margin:'0 auto' }}>
          <SHead eye={t.eye} title={t.title} sub={t.sub} isGu={isGu} center={false}/>
          <div style={{ borderLeft:`2px solid ${C.gold}`, paddingLeft:16, background:C.goldLL, padding:'12px 12px 12px 16px', marginBottom:16 }}>
            <p style={{ fontSize:13, color:C.tx2, lineHeight:1.9, fontFamily:isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{t.d1}</p>
          </div>
          <p style={{ fontSize:13, color:C.tx2, lineHeight:1.9, marginBottom:32, fontFamily:isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif" }}>{t.d2}</p>
          {/* Committee */}
          <div style={{ border:`1px solid ${C.bd}`, overflow:'hidden' }}>
            <div style={{ background:C.maroon, padding:'16px 20px' }}>
              <p style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:20, color:'#fff', fontWeight:600 }}>{t.committeeTitle}</p>
              <p style={{ fontSize:9, color:'rgba(255,255,255,0.6)', letterSpacing:2, textTransform:'uppercase', marginTop:3 }}>{t.committeeSub}</p>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:1, background:C.bd, margin:'1px 0' }}>
              {roles.map(({r,n}) => (
                <div key={r} style={{ background:C.bg2, padding:'14px 16px' }}>
                  <div style={{ fontSize:8, color:C.sf, letterSpacing:2, textTransform:'uppercase', marginBottom:4, fontWeight:600, fontFamily:"'Inter',sans-serif" }}>{r}</div>
                  <div style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:15, color:C.maroon, fontWeight:700 }}>{n}</div>
                </div>
              ))}
            </div>
            {/* Stage members */}
            <div style={{ padding:'16px 20px', background:C.white }}>
              <p style={{ fontSize:8, color:C.sf, letterSpacing:2, textTransform:'uppercase', marginBottom:12, fontWeight:600, fontFamily:"'Inter',sans-serif" }}>{t.members}</p>
              <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                {t.membersList.map((m:string) => (
                  <span key={m} style={{ fontSize:11, color:C.tx2, background:C.bg2, border:`1px solid ${C.bd}`, padding:'4px 10px', fontFamily:"'Inter',sans-serif" }}>{m}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

// ─── FOOTER ───────────────────────────────────────────────────────────────────
function Footer({ lang, t, go }: { lang:Lang; t:typeof T['en']['footer']; go:(p:Page)=>void }) {
  const isGu = lang === 'gu';
  return (
    <footer style={{ background:C.maroon, padding:'28px 24px', textAlign:'center' }}>
      <p style={{ fontFamily:"'Cormorant Garamond',serif", fontSize:18, color:'#F5C87A', marginBottom:8, fontStyle:'italic' }}>{t.mantra}</p>
      <p style={{ fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Cormorant Garamond',serif", fontSize:13, color:'rgba(255,255,255,0.8)', marginBottom:4 }}>{t.event}</p>
      <p style={{ fontFamily: isGu?"'Noto Sans Gujarati',sans-serif":"'Inter',sans-serif", fontSize:10, color:'rgba(255,255,255,0.5)', marginBottom:12 }}>{t.address}</p>
      <div style={{ display:'flex', justifyContent:'center', gap:20, marginBottom:12 }}>
        {(['home','darshan','albums','upload','about'] as Page[]).map(p => (
          <button key={p} onClick={()=>go(p)} style={{ background:'none', border:'none', color:'rgba(255,255,255,0.5)', fontSize:9, letterSpacing:2, textTransform:'uppercase', cursor:'pointer', fontFamily:"'Inter',sans-serif" }}>{p}</button>
        ))}
      </div>
      <p style={{ fontSize:8, color:'rgba(255,255,255,0.3)', letterSpacing:2, textTransform:'uppercase' }}>{t.organizer} · {new Date().getFullYear()}</p>
    </footer>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [lang, setLang] = useState<Lang>('en');
  const [page, setPage] = useState<Page>('home');
  const go = (p: Page) => { setPage(p); window.scrollTo({top:0,behavior:'smooth'}); };
  useEffect(() => { window.scrollTo({top:0}); }, [page]);
  const tr = T[lang];

  return (
    <div style={{ minHeight:'100vh', background:C.bg, color:C.tx, fontFamily:"'Inter',sans-serif" }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;0,700;1,400;1,600&family=Noto+Sans+Gujarati:wght@300;400;600;700&family=Inter:wght@300;400;500;600&display=swap'); *{box-sizing:border-box;margin:0;padding:0;} button{cursor:pointer;}`}</style>
      <Navbar lang={lang} page={page} go={go} toggleLang={()=>setLang(l=>l==='en'?'gu':'en')} t={tr.nav}/>
      <main>
        {page==='home' && <HomePage lang={lang} t={tr} go={go}/>}
        {page==='darshan' && <DarshanPage lang={lang} t={tr.darshan}/>}
        {page==='albums' && <AlbumsPage lang={lang} t={tr.albums}/>}
        {page==='upload' && <UploadPage lang={lang} t={tr.upload}/>}
        {page==='about' && <AboutPage lang={lang} t={tr.about}/>}
      </main>
      <Footer lang={lang} t={tr.footer} go={go}/>
    </div>
  );
}
