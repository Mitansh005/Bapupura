import { useState } from 'react';

type Page = 'home' | 'about' | 'albums' | 'upload';
type Lang = 'en' | 'gu';

interface NavbarProps {
  lang: Lang;
  activePage: Page;
  onNavigate: (page: Page) => void;
  onLangToggle: () => void;
  labels: { home: string; about: string; albums: string; upload: string; langToggle: string };
}

export function Navbar({ lang, activePage, onNavigate, onLangToggle, labels }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const isGu = lang === 'gu';

  const items: { key: Page; label: string }[] = [
    { key: 'home', label: labels.home },
    { key: 'about', label: labels.about },
    { key: 'albums', label: labels.albums },
    { key: 'upload', label: labels.upload },
  ];

  const go = (page: Page) => { onNavigate(page); setMobileOpen(false); };

  return (
    <nav style={{ position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50, background: 'rgba(13,9,6,0.94)', backdropFilter: 'blur(12px)', borderBottom: '1px solid rgba(200,146,42,0.14)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '0 24px', height: '64px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        {/* Logo */}
        <button onClick={() => go('home')} style={{ background: 'none', border: 'none', padding: 0, display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
          <svg width="20" height="26" viewBox="0 0 22 28" fill="none">
            <line x1="11" y1="6" x2="11" y2="27" stroke="#C8922A" strokeWidth="1.5"/>
            <path d="M11 6L7 2M11 6L15 2" stroke="#C8922A" strokeWidth="1.5" strokeLinecap="round"/>
            <path d="M5 2C3 2 2 4 2 6c0 3 3 4 5 2" stroke="#C8922A" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
            <path d="M17 2c2 0 3 2 3 4 0 3-3 4-5 2" stroke="#C8922A" strokeWidth="1.2" strokeLinecap="round" fill="none"/>
            <line x1="8" y1="18" x2="14" y2="18" stroke="#C8922A" strokeWidth="1.2"/>
          </svg>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
            <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: '1.1rem', fontWeight: 600, color: '#C8922A', lineHeight: 1.1 }}>
              {isGu ? 'બાપુપૂરા' : 'Bapupura'}
            </span>
            <span style={{ fontSize: '0.58rem', color: '#9A8A76', letterSpacing: '0.18em', textTransform: 'uppercase', lineHeight: 1, fontFamily: "'Inter',sans-serif" }}>
              Mansa · Gujarat
            </span>
          </div>
        </button>

        {/* Desktop nav */}
        <div className="hidden md:flex" style={{ alignItems: 'center', gap: '6px' }}>
          {items.map(({ key, label }) => (
            <button key={key} onClick={() => go(key)}
              style={{ background: 'none', border: 'none', padding: '6px 14px', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.85rem' : '0.75rem', letterSpacing: isGu ? 0 : '0.12em', textTransform: isGu ? 'none' : 'uppercase', color: activePage === key ? '#C8922A' : '#9A8A76', fontWeight: activePage === key ? 500 : 400, borderBottom: activePage === key ? '1px solid #C8922A' : '1px solid transparent', cursor: 'pointer', transition: 'color 200ms ease-out' }}
              onMouseEnter={e => { if (activePage !== key) (e.currentTarget as HTMLElement).style.color = '#F2E8D5'; }}
              onMouseLeave={e => { if (activePage !== key) (e.currentTarget as HTMLElement).style.color = '#9A8A76'; }}
            >{label}</button>
          ))}
          <button onClick={onLangToggle}
            style={{ marginLeft: '10px', padding: '5px 14px', background: 'rgba(200,146,42,0.1)', border: '1px solid rgba(200,146,42,0.35)', color: '#C8922A', fontSize: '0.75rem', cursor: 'pointer', fontFamily: isGu ? "'Inter',sans-serif" : "'Noto Sans Gujarati',sans-serif", transition: 'background 200ms ease-out' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(200,146,42,0.2)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = 'rgba(200,146,42,0.1)'; }}
          >{labels.langToggle}</button>
        </div>

        {/* Mobile toggle */}
        <button className="flex md:hidden" onClick={() => setMobileOpen(!mobileOpen)} style={{ background: 'none', border: 'none', padding: '8px', cursor: 'pointer' }}>
          <svg width="22" height="16" viewBox="0 0 22 16" fill="none">
            {mobileOpen ? (
              <><line x1="1" y1="1" x2="19" y2="15" stroke="#C8922A" strokeWidth="1.5"/><line x1="19" y1="1" x2="1" y2="15" stroke="#C8922A" strokeWidth="1.5"/></>
            ) : (
              <><line x1="0" y1="1" x2="22" y2="1" stroke="#C8922A" strokeWidth="1.5"/><line x1="0" y1="8" x2="22" y2="8" stroke="#C8922A" strokeWidth="1.5"/><line x1="0" y1="15" x2="22" y2="15" stroke="#C8922A" strokeWidth="1.5"/></>
            )}
          </svg>
        </button>
      </div>

      {mobileOpen && (
        <div style={{ background: 'rgba(13,9,6,0.98)', borderTop: '1px solid rgba(200,146,42,0.12)', padding: '16px 24px 24px' }}>
          {items.map(({ key, label }) => (
            <button key={key} onClick={() => go(key)} style={{ display: 'block', width: '100%', textAlign: 'left', background: 'none', border: 'none', padding: '12px 0', borderBottom: '1px solid rgba(200,146,42,0.08)', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: '1rem', color: activePage === key ? '#C8922A' : '#F2E8D5', cursor: 'pointer' }}>
              {label}
            </button>
          ))}
          <button onClick={() => { onLangToggle(); setMobileOpen(false); }} style={{ marginTop: '16px', padding: '8px 20px', background: 'rgba(200,146,42,0.1)', border: '1px solid rgba(200,146,42,0.35)', color: '#C8922A', fontSize: '0.85rem', cursor: 'pointer', fontFamily: isGu ? "'Inter',sans-serif" : "'Noto Sans Gujarati',sans-serif" }}>
            {labels.langToggle}
          </button>
        </div>
      )}
    </nav>
  );
}
