interface OrnamentalDividerProps {
  symbol?: string;
  className?: string;
}

export function OrnamentalDivider({ symbol = '❈', className = '' }: OrnamentalDividerProps) {
  return (
    <div className={`flex items-center gap-5 px-4 ${className}`}>
      <div className="flex-1 h-px" style={{ background: 'linear-gradient(to right, transparent, rgba(200,146,42,0.6))' }} />
      <span className="shrink-0 select-none" style={{ color: '#C8922A', fontSize: '0.8rem', letterSpacing: '0.4em' }}>
        {symbol}
      </span>
      <div className="flex-1 h-px" style={{ background: 'linear-gradient(to left, transparent, rgba(200,146,42,0.6))' }} />
    </div>
  );
}
