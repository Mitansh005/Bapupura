import { useState, useEffect } from 'react';

interface CountdownTimerProps {
  targetDate: Date;
  labels: { days: string; hours: string; minutes: string; seconds: string };
}

function getTimeLeft(target: Date) {
  const diff = target.getTime() - Date.now();
  if (diff <= 0) return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

function pad(n: number) { return String(n).padStart(2, '0'); }

export function CountdownTimer({ targetDate, labels }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState(getTimeLeft(targetDate));
  useEffect(() => {
    const id = setInterval(() => setTimeLeft(getTimeLeft(targetDate)), 1000);
    return () => clearInterval(id);
  }, [targetDate]);

  const units = [
    { value: timeLeft.days, label: labels.days },
    { value: timeLeft.hours, label: labels.hours },
    { value: timeLeft.minutes, label: labels.minutes },
    { value: timeLeft.seconds, label: labels.seconds },
  ];

  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 'clamp(8px, 2vw, 16px)' }}>
      {units.map(({ value, label }, i) => (
        <div key={label} style={{ display: 'flex', alignItems: 'flex-end', gap: 'clamp(8px, 2vw, 16px)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <div style={{
              width: 'clamp(58px, 13vw, 84px)', height: 'clamp(58px, 13vw, 84px)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: 'rgba(200,146,42,0.08)', border: '1px solid rgba(200,146,42,0.28)',
            }}>
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 'clamp(1.7rem, 5vw, 2.8rem)', color: '#C8922A', fontWeight: 300, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>
                {pad(value)}
              </span>
            </div>
            <span style={{ fontSize: '0.6rem', color: '#9A8A76', letterSpacing: '0.15em', textTransform: 'uppercase', marginTop: '6px', fontFamily: "'Inter', sans-serif" }}>
              {label}
            </span>
          </div>
          {i < units.length - 1 && (
            <span style={{ color: 'rgba(200,146,42,0.45)', fontSize: 'clamp(1.4rem, 4vw, 2.2rem)', fontFamily: "'Cormorant Garamond', serif", fontWeight: 300, lineHeight: 1, marginBottom: '1.5rem', userSelect: 'none' }}>:</span>
          )}
        </div>
      ))}
    </div>
  );
}
