import { OrnamentalDivider } from './OrnamentalDivider';
import { ImageWithFallback } from './figma/ImageWithFallback';
import festivalCover from '../../imports/WhatsApp_Image_2026-06-09_at_10.57.38_AM__1_.jpeg';
import committeeCover from '../../imports/WhatsApp_Image_2026-06-09_at_11.09.18_AM.jpeg';

const ALBUMS = [
  { id: 1, titleEn: 'Shri Nilkanth Mahadev Maha Mahotsav', titleGu: 'શ્રી નિ' + 'લ' + 'ક' + 'ં' + 'ઠ મ' + 'હ' + 'ા' + 'દ' + 'ે' + 'વ મ' + 'હ' + 'ા મ' + 'હ' + 'ો' + 'ત' + 'સ' + 'વ', dateEn: 'June 6, 2026', dateGu: '૬ જ' + 'ૂ' + 'ન ૨૦૨૬', status: 'recent' as const, photoCount: 24, cover: 'festival' },
  { id: 2, titleEn: 'Committee Meeting & Planning', titleGu: 'ક' + 'મ' + 'િ' + 'ટ' + 'ી મ' + 'િ' + 'ટ' + 'િ' + 'ં' + 'ગ', dateEn: 'June 2026', dateGu: 'જ' + 'ૂ' + 'ન ૨૦૨૬', status: 'recent' as const, photoCount: 12, cover: 'committee' },
  { id: 3, titleEn: 'Maha Mahotsav 2026', titleGu: 'મ' + 'હ' + 'ા મ' + 'હ' + 'ો' + 'ત' + 'સ' + 'વ ૨૦૨૬', dateEn: 'October 5, 2026', dateGu: 'ઓ' + 'ક' + '્' + 'ટ' + 'ો' + 'બ' + 'ર ૨૦૨૬', status: 'upcoming' as const, photoCount: 0, cover: null },
];

const STATUS_COLORS = {
  upcoming: { bg: 'rgba(200,146,42,0.1)', text: '#C8922A', border: 'rgba(200,146,42,0.35)' },
  recent: { bg: 'rgba(100,160,80,0.08)', text: '#7AB860', border: 'rgba(100,160,80,0.28)' },
  past: { bg: 'rgba(154,138,118,0.08)', text: '#9A8A76', border: 'rgba(154,138,118,0.22)' },
};

interface AlbumsGridProps {
  lang: 'en' | 'gu';
  labels: { sectionLabel: string; title: string; subtitle: string; statusUpcoming: string; statusRecent: string; statusPast: string; photosCount: (n: number) => string; viewAlbum: string; emptyState: string; adminNote: string };
}

export function AlbumsGrid({ lang, labels }: AlbumsGridProps) {
  const isGu = lang === 'gu';
  return (
    <section style={{ background: '#0D0906', padding: 'clamp(64px,10vw,120px) clamp(20px,5vw,80px)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '52px' }}>
          <p style={{ fontSize: '0.65rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '16px' }}>{labels.sectionLabel}</p>
          <h2 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1.8rem,5vw,2.8rem)' : 'clamp(2rem,5vw,3.2rem)', color: '#F2E8D5', fontWeight: isGu ? 600 : 400, marginBottom: '8px' }}>{labels.title}</h2>
          <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '0.9rem' : '1.05rem', color: '#9A8A76', fontStyle: isGu ? 'normal' : 'italic', marginBottom: '22px' }}>{labels.subtitle}</p>
          <OrnamentalDivider symbol="❈" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(min(100%,320px),1fr))', gap: '22px' }}>
          {ALBUMS.map(album => {
            const title = isGu ? album.titleGu : album.titleEn;
            const date = isGu ? album.dateGu : album.dateEn;
            const statusLabel = album.status === 'upcoming' ? labels.statusUpcoming : album.status === 'recent' ? labels.statusRecent : 'Past';
            const sc = STATUS_COLORS[album.status];
            return (
              <div key={album.id}
                style={{ background: '#100C09', border: '1px solid rgba(200,146,42,0.16)', display: 'flex', flexDirection: 'column', transition: 'border-color 200ms ease-out,transform 150ms ease-out', cursor: album.status !== 'upcoming' ? 'pointer' : 'default' }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,146,42,0.42)'; if (album.status !== 'upcoming') (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)'; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,146,42,0.16)'; (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; }}
              >
                {/* Cover */}
                <div style={{ width: '100%', aspectRatio: '16/9', overflow: 'hidden', position: 'relative', background: '#160E0B' }}>
                  {album.cover === 'festival' ? (
                    <ImageWithFallback src={festivalCover} alt={title} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                  ) : album.cover === 'committee' ? (
                    <ImageWithFallback src={committeeCover} alt={title} style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'top', display: 'block' }} />
                  ) : (
                    <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: '6px' }}>
                      <span style={{ fontSize: '2.2rem', color: 'rgba(200,146,42,0.18)', fontFamily: 'serif' }}>ॐ</span>
                      <span style={{ fontSize: '0.65rem', color: 'rgba(154,138,118,0.45)', letterSpacing: '0.12em', textTransform: 'uppercase', fontFamily: "'Inter',sans-serif" }}>{labels.emptyState}</span>
                    </div>
                  )}
                  {album.cover && <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom,transparent 50%,rgba(13,9,6,0.55) 100%)', pointerEvents: 'none' }} />}
                </div>
                {/* Body */}
                <div style={{ padding: '18px 20px 20px', flex: 1, display: 'flex', flexDirection: 'column', gap: '9px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <span style={{ fontSize: '0.58rem', letterSpacing: '0.18em', textTransform: 'uppercase', padding: '3px 9px', background: sc.bg, border: `1px solid ${sc.border}`, color: sc.text, fontFamily: "'Inter',sans-serif" }}>{statusLabel}</span>
                    <span style={{ fontSize: '0.68rem', color: '#9A8A76', fontFamily: "'Inter',sans-serif" }}>{labels.photosCount(album.photoCount)}</span>
                  </div>
                  <h3 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '1rem' : '1.15rem', color: '#F2E8D5', fontWeight: isGu ? 600 : 500, lineHeight: 1.3, flex: 1 }}>{title}</h3>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '2px' }}>
                    <span style={{ fontSize: '0.72rem', color: '#9A8A76', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif" }}>{date}</span>
                    {album.status !== 'upcoming' && (
                      <span style={{ fontSize: '0.68rem', color: '#C8922A', letterSpacing: '0.1em', textTransform: 'uppercase', fontFamily: "'Inter',sans-serif", display: 'flex', alignItems: 'center', gap: '3px' }}>
                        {labels.viewAlbum}
                        <svg width="9" height="9" viewBox="0 0 9 9" fill="none"><path d="M1 4.5h7M5 2l2.5 2.5L5 7" stroke="#C8922A" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round"/></svg>
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <p style={{ textAlign: 'center', marginTop: '36px', fontSize: '0.7rem', color: 'rgba(154,138,118,0.45)', letterSpacing: '0.08em', fontFamily: "'Inter',sans-serif" }}>{labels.adminNote}</p>
      </div>
    </section>
  );
}
