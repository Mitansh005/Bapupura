import { OrnamentalDivider } from './OrnamentalDivider';
import { ImageWithFallback } from './figma/ImageWithFallback';
import pujaImg from '../../imports/WhatsApp_Image_2026-06-09_at_10.57.36_AM.jpeg';

interface TempleSectionProps {
  lang: 'en' | 'gu';
  labels: { sectionLabel: string; title: string; subtitle: string; desc1: string; desc2: string; pujaTitle: string; pujaLabel: string; pujaTime: string; pujaLocation: string; pujaDetail: string; pujaNote: string; mantraLabel: string };
}

export function TempleSection({ lang, labels }: TempleSectionProps) {
  const isGu = lang === 'gu';
  return (
    <section style={{ background: '#0D0906', padding: 'clamp(64px,10vw,120px) clamp(20px,5vw,80px)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '52px' }}>
          <p style={{ fontSize: '0.65rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '16px' }}>{labels.sectionLabel}</p>
          <OrnamentalDivider symbol="❈" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,400px),1fr))', gap: 'clamp(40px,6vw,80px)', alignItems: 'start' }}>
          {/* Text */}
          <div>
            <h2 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1.8rem,5vw,2.8rem)' : 'clamp(2rem,5vw,3.2rem)', fontWeight: isGu ? 600 : 400, color: '#C8922A', marginBottom: '6px', lineHeight: 1.1 }}>{labels.title}</h2>
            <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '0.95rem' : '1.05rem', color: '#9A8A76', fontStyle: isGu ? 'normal' : 'italic', marginBottom: '28px' }}>{labels.subtitle}</p>
            <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.95rem' : '0.9rem', lineHeight: isGu ? 1.9 : 1.8, color: '#9A8A76', marginBottom: '18px' }}>{labels.desc1}</p>
            <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.95rem' : '0.9rem', lineHeight: isGu ? 1.9 : 1.8, color: '#9A8A76', marginBottom: '36px' }}>{labels.desc2}</p>
            <p style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 'clamp(1rem,2.5vw,1.3rem)', color: 'rgba(200,146,42,0.7)', letterSpacing: '0.1em', fontStyle: 'italic' }}>{labels.mantraLabel}</p>
          </div>

          {/* Puja card + image */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '28px' }}>
            <div style={{ background: '#100C09', border: '1px solid rgba(200,146,42,0.2)', padding: 'clamp(22px,4vw,38px)', position: 'relative', overflow: 'hidden' }}>
              {/* Corner brackets */}
              <div style={{ position: 'absolute', top: 0, left: 0, width: '48px', height: '48px', borderRight: '1px solid rgba(200,146,42,0.12)', borderBottom: '1px solid rgba(200,146,42,0.12)', pointerEvents: 'none' }} />
              <div style={{ position: 'absolute', top: 0, right: 0, width: '48px', height: '48px', borderLeft: '1px solid rgba(200,146,42,0.12)', borderBottom: '1px solid rgba(200,146,42,0.12)', pointerEvents: 'none' }} />
              <p style={{ fontSize: '0.58rem', letterSpacing: '0.3em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '12px' }}>{labels.pujaLabel}</p>
              <h3 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1.3rem,4vw,1.9rem)' : 'clamp(1.5rem,4vw,2.2rem)', color: '#F2E8D5', fontWeight: isGu ? 600 : 400, marginBottom: '20px', lineHeight: 1.1 }}>{labels.pujaTitle}</h3>
              <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '10px' }}>
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><circle cx="7" cy="7" r="6" stroke="#C8922A" strokeWidth="1.1" opacity="0.7"/><path d="M7 4v3.5l2 1.2" stroke="#C8922A" strokeWidth="1.1" strokeLinecap="round" opacity="0.7"/></svg>
                <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.9rem' : '0.85rem', color: '#F2E8D5', fontWeight: 500 }}>{labels.pujaTime}</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '9px', marginBottom: '18px' }}>
                <svg width="12" height="15" viewBox="0 0 12 15" fill="none" style={{ marginTop: '1px', flexShrink: 0 }}><path d="M6 0C3.24 0 1 2.24 1 5c0 3.75 5 10 5 10s5-6.25 5-10c0-2.76-2.24-5-5-5zm0 6.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3z" fill="#C8922A" opacity="0.7"/></svg>
                <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.85rem' : '0.8rem', color: '#9A8A76', lineHeight: 1.5 }}>{labels.pujaLocation}</span>
              </div>
              <div style={{ height: '1px', background: 'rgba(200,146,42,0.13)', marginBottom: '14px' }} />
              <p style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: '1rem', color: '#C8922A', fontStyle: 'italic', marginBottom: '8px' }}>{labels.pujaDetail}</p>
              <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: '0.72rem', color: '#9A8A76', lineHeight: 1.6 }}>{labels.pujaNote}</p>
            </div>

            <div style={{ border: '1px solid rgba(200,146,42,0.18)', overflow: 'hidden', position: 'relative' }}>
              <ImageWithFallback src={pujaImg} alt="Shri Nilkanth Mahadev weekly puja announcement" style={{ width: '100%', display: 'block', objectFit: 'cover', aspectRatio: '1/1' }} />
              <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom,transparent 60%,rgba(13,9,6,0.4) 100%)', pointerEvents: 'none' }} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
