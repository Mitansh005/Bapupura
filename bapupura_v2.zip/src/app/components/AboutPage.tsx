import { OrnamentalDivider } from './OrnamentalDivider';
import { ImageWithFallback } from './figma/ImageWithFallback';
import committeeImg from '../../imports/WhatsApp_Image_2026-06-09_at_11.09.18_AM.jpeg';

interface AboutPageProps {
  lang: 'en' | 'gu';
  labels: { sectionLabel: string; title: string; subtitle: string; desc1: string; desc2: string; committeeTitle: string; committeeSubtitle: string; pramukh: string; mantri: string; pravakta: string; sanyojak: string; committeeMembers: string[]; pramukhName: string; mantriName: string; pravaktaName: string; sanyojakName: string };
}

export function AboutPage({ lang, labels }: AboutPageProps) {
  const isGu = lang === 'gu';
  const leadership = [
    { role: labels.pramukh, name: labels.pramukhName },
    { role: labels.mantri, name: labels.mantriName },
    { role: labels.pravakta, name: labels.pravaktaName },
    { role: labels.sanyojak, name: labels.sanyojakName },
  ];
  return (
    <section style={{ background: '#0D0906', padding: 'clamp(64px,10vw,120px) clamp(20px,5vw,80px)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '52px' }}>
          <p style={{ fontSize: '0.65rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '16px' }}>{labels.sectionLabel}</p>
          <h2 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(2rem,6vw,4rem)' : 'clamp(2.5rem,7vw,5rem)', color: '#F2E8D5', fontWeight: isGu ? 700 : 300, marginBottom: '8px', lineHeight: 1.05 }}>{labels.title}</h2>
          <p style={{ fontSize: '0.72rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#9A8A76', fontFamily: "'Inter',sans-serif", marginBottom: '22px' }}>{labels.subtitle}</p>
          <OrnamentalDivider symbol="❈" />
        </div>

        <div style={{ maxWidth: '740px', margin: '0 auto 64px', textAlign: 'center' }}>
          <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '1rem' : '0.925rem', lineHeight: isGu ? 1.9 : 1.85, color: '#9A8A76', marginBottom: '18px' }}>{labels.desc1}</p>
          <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '1rem' : '0.925rem', lineHeight: isGu ? 1.9 : 1.85, color: '#9A8A76' }}>{labels.desc2}</p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(min(100%,380px),1fr))', gap: 'clamp(36px,6vw,72px)', alignItems: 'start' }}>
          <div style={{ border: '1px solid rgba(200,146,42,0.18)', overflow: 'hidden', position: 'relative' }}>
            <ImageWithFallback src={committeeImg} alt="Shri Nilkanth Mahadev Maha Mahotsav Organizing Committee" style={{ width: '100%', display: 'block', objectFit: 'cover' }} />
            <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(to bottom,transparent 60%,rgba(13,9,6,0.45) 100%)', pointerEvents: 'none' }} />
          </div>

          <div>
            <p style={{ fontSize: '0.62rem', letterSpacing: '0.28em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '10px' }}>{labels.committeeTitle}</p>
            <h3 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '1.15rem' : '1.45rem', color: '#F2E8D5', fontWeight: isGu ? 600 : 400, marginBottom: '24px' }}>{labels.committeeSubtitle}</h3>

            <div style={{ background: '#100C09', border: '1px solid rgba(200,146,42,0.16)', padding: '20px', marginBottom: '24px' }}>
              {labels.committeeMembers.map((member, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '8px 0', borderBottom: i < labels.committeeMembers.length - 1 ? '1px solid rgba(200,146,42,0.07)' : 'none' }}>
                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><path d="M5 1l1.2 2.8L9 4.2 7 6.2l.5 2.8L5 7.5 2.5 9l.5-2.8L1 4.2l2.8-.4L5 1z" fill="#C8922A" opacity="0.6"/></svg>
                  <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.85rem' : '0.8rem', color: '#F2E8D5', lineHeight: 1.4 }}>{member}</span>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {leadership.map(({ role, name }) => (
                <div key={role} style={{ display: 'flex', alignItems: 'baseline', gap: '10px' }}>
                  <span style={{ fontSize: '0.58rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", minWidth: '72px', flexShrink: 0 }}>{role}</span>
                  <div style={{ flex: 1, height: '1px', background: 'rgba(200,146,42,0.13)', alignSelf: 'center' }} />
                  <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.85rem' : '0.8rem', color: '#F2E8D5', textAlign: 'right' }}>{name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
