import { useState, useRef } from 'react';
import { OrnamentalDivider } from './OrnamentalDivider';

const ALBUMS_EN = ['Shri Nilkanth Mahadev Maha Mahotsav — June 2026', 'Committee Meeting — June 2026', 'Maha Mahotsav 2026 — October 2026'];
const ALBUMS_GU = ['શ' + '્' + 'ર' + 'ી ન' + 'િ' + 'લ' + 'ક' + 'ં' + 'ઠ — જ' + 'ૂ' + 'ન ૨૦૨૬', 'ક' + 'મ' + 'િ' + 'ટ' + 'ી — જ' + 'ૂ' + 'ન ૨૦૨૬', 'મ' + 'હ' + 'ો' + 'ત' + 'સ' + 'વ — ઓ' + 'ક' + '્' + 'ટ' + 'ો' + 'બ' + 'ર ૨૦૨૬'];

interface PhotoUploadProps {
  lang: 'en' | 'gu';
  labels: { sectionLabel: string; title: string; subtitle: string; nameLabel: string; namePlaceholder: string; contactLabel: string; contactPlaceholder: string; albumLabel: string; albumPlaceholder: string; captionLabel: string; captionPlaceholder: string; dropzone: string; dropzoneSub: string; submit: string; submitting: string; successTitle: string; successMsg: string; submitAnother: string; approvalNotice: string; selectedFiles: (n: number) => string };
}

export function PhotoUpload({ lang, labels }: PhotoUploadProps) {
  const isGu = lang === 'gu';
  const [name, setName] = useState('');
  const [contact, setContact] = useState('');
  const [album, setAlbum] = useState('');
  const [caption, setCaption] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const albumOptions = isGu ? ALBUMS_GU : ALBUMS_EN;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || files.length === 0) return;
    setSubmitting(true);
    setTimeout(() => { setSubmitting(false); setSubmitted(true); }, 1800);
  };

  const inputStyle: React.CSSProperties = { width: '100%', padding: '10px 14px', background: '#160E0B', border: '1px solid rgba(200,146,42,0.18)', color: '#F2E8D5', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.9rem' : '0.875rem', outline: 'none', boxSizing: 'border-box', transition: 'border-color 200ms ease-out' };
  const labelStyle: React.CSSProperties = { display: 'block', fontSize: '0.62rem', letterSpacing: '0.2em', textTransform: 'uppercase', color: '#9A8A76', fontFamily: "'Inter',sans-serif", marginBottom: '7px' };
  const focus = (e: React.FocusEvent) => { (e.target as HTMLElement).style.borderColor = 'rgba(200,146,42,0.5)'; };
  const blur = (e: React.FocusEvent) => { (e.target as HTMLElement).style.borderColor = 'rgba(200,146,42,0.18)'; };

  return (
    <section style={{ background: '#0D0906', padding: 'clamp(64px,10vw,120px) clamp(20px,5vw,80px)' }}>
      <div style={{ maxWidth: '640px', margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: '52px' }}>
          <p style={{ fontSize: '0.65rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '16px' }}>{labels.sectionLabel}</p>
          <h2 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1.8rem,5vw,2.8rem)' : 'clamp(2rem,5vw,3.2rem)', color: '#F2E8D5', fontWeight: isGu ? 600 : 400, marginBottom: '10px' }}>{labels.title}</h2>
          <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.9rem' : '0.875rem', color: '#9A8A76', lineHeight: 1.7, marginBottom: '22px' }}>{labels.subtitle}</p>
          <OrnamentalDivider symbol="❈" />
        </div>

        {submitted ? (
          <div style={{ textAlign: 'center', padding: '56px 36px', background: '#100C09', border: '1px solid rgba(200,146,42,0.2)' }}>
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none"><circle cx="24" cy="24" r="22" stroke="#C8922A" strokeWidth="1.4" opacity="0.4"/><path d="M14 24l7 7 13-14" stroke="#C8922A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
            <h3 style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 'clamp(1.3rem,4vw,1.9rem)', color: '#C8922A', marginTop: '18px', marginBottom: '10px' }}>{labels.successTitle}</h3>
            <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: '0.875rem', color: '#9A8A76', lineHeight: 1.7, maxWidth: '420px', margin: '0 auto 28px' }}>{labels.successMsg}</p>
            <button onClick={() => { setName(''); setContact(''); setAlbum(''); setCaption(''); setFiles([]); setSubmitted(false); }}
              style={{ padding: '10px 26px', background: 'rgba(200,146,42,0.1)', border: '1px solid rgba(200,146,42,0.35)', color: '#C8922A', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: '0.8rem', letterSpacing: isGu ? 0 : '0.1em', textTransform: isGu ? 'none' : 'uppercase', cursor: 'pointer' }}>
              {labels.submitAnother}
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '22px' }}>
            <div><label style={labelStyle}>{labels.nameLabel}</label><input type="text" required value={name} onChange={e => setName(e.target.value)} placeholder={labels.namePlaceholder} style={inputStyle} onFocus={focus} onBlur={blur} /></div>
            <div><label style={labelStyle}>{labels.contactLabel}</label><input type="tel" value={contact} onChange={e => setContact(e.target.value)} placeholder={labels.contactPlaceholder} style={inputStyle} onFocus={focus} onBlur={blur} /></div>
            <div>
              <label style={labelStyle}>{labels.albumLabel}</label>
              <select value={album} onChange={e => setAlbum(e.target.value)} style={{ ...inputStyle, appearance: 'none', backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='7' viewBox='0 0 12 7'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23C8922A' stroke-width='1.4' stroke-linecap='round'/%3E%3C/svg%3E\")", backgroundRepeat: 'no-repeat', backgroundPosition: 'right 13px center', paddingRight: '34px', cursor: 'pointer' }} onFocus={focus} onBlur={blur}>
                <option value="" disabled style={{ background: '#160E0B' }}>{labels.albumPlaceholder}</option>
                {albumOptions.map((o, i) => <option key={i} value={o} style={{ background: '#160E0B' }}>{o}</option>)}
              </select>
            </div>
            <div><label style={labelStyle}>{labels.captionLabel}</label><textarea value={caption} onChange={e => setCaption(e.target.value)} placeholder={labels.captionPlaceholder} rows={3} style={{ ...inputStyle, resize: 'vertical', minHeight: '78px' }} onFocus={focus} onBlur={blur} /></div>

            {/* Dropzone */}
            <div>
              <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple style={{ display: 'none' }} onChange={e => e.target.files && setFiles(Array.from(e.target.files))} />
              <div onClick={() => fileRef.current?.click()} onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onDrop={e => { e.preventDefault(); setDragOver(false); e.dataTransfer.files && setFiles(Array.from(e.dataTransfer.files)); }}
                style={{ padding: '34px 22px', border: `1px dashed ${dragOver ? 'rgba(200,146,42,0.65)' : files.length > 0 ? 'rgba(200,146,42,0.5)' : 'rgba(200,146,42,0.2)'}`, background: dragOver ? 'rgba(200,146,42,0.05)' : 'rgba(22,14,11,0.5)', cursor: 'pointer', textAlign: 'center', transition: 'border-color 200ms,background 200ms', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '9px' }}>
                <svg width="30" height="30" viewBox="0 0 30 30" fill="none"><path d="M15 21V9M9 15l6-6 6 6" stroke="#C8922A" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" opacity="0.65"/><rect x="3" y="23" width="24" height="4" rx="1" stroke="#C8922A" strokeWidth="1.1" opacity="0.35"/></svg>
                {files.length > 0
                  ? <p style={{ fontSize: '0.875rem', color: '#C8922A', fontFamily: "'Inter',sans-serif" }}>{labels.selectedFiles(files.length)}</p>
                  : <><p style={{ fontSize: '0.875rem', color: '#9A8A76', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif" }}>{labels.dropzone}</p><p style={{ fontSize: '0.68rem', color: 'rgba(154,138,118,0.45)', fontFamily: "'Inter',sans-serif", letterSpacing: '0.08em' }}>{labels.dropzoneSub}</p></>
                }
              </div>
            </div>

            <button type="submit" disabled={submitting || !name.trim() || files.length === 0}
              style={{ padding: '13px 32px', background: submitting || !name.trim() || files.length === 0 ? 'rgba(200,146,42,0.28)' : '#C8922A', border: 'none', color: '#0D0906', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.95rem' : '0.78rem', fontWeight: 600, letterSpacing: isGu ? 0 : '0.12em', textTransform: isGu ? 'none' : 'uppercase', cursor: submitting || !name.trim() || files.length === 0 ? 'not-allowed' : 'pointer', transition: 'background 200ms ease-out' }}
              onMouseEnter={e => { if (!submitting && name.trim() && files.length > 0) (e.currentTarget as HTMLElement).style.background = '#E4AE4A'; }}
              onMouseLeave={e => { if (!submitting && name.trim() && files.length > 0) (e.currentTarget as HTMLElement).style.background = '#C8922A'; }}
            >{submitting ? labels.submitting : labels.submit}</button>
            <p style={{ textAlign: 'center', fontSize: '0.7rem', color: 'rgba(154,138,118,0.45)', fontFamily: "'Cormorant Garamond',serif", fontStyle: 'italic', letterSpacing: '0.05em' }}>{labels.approvalNotice}</p>
          </form>
        )}
      </div>
    </section>
  );
}
