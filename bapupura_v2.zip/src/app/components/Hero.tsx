import { CountdownTimer } from './CountdownTimer';
import { ImageWithFallback } from './figma/ImageWithFallback';
import bannerImg from '../../imports/WhatsApp_Image_2026-06-09_at_10.57.38_AM__1_.jpeg';

type Page = 'home' | 'about' | 'albums' | 'upload';

interface HeroProps {
  lang: 'en' | 'gu';
  onNavigate: (page: Page) => void;
  labels: { villageName: string; tagline: string; subTagline: string; countdownTitle: string; countdownSub: string; days: string; hours: string; minutes: string; seconds: string; cta1: string; cta2: string; mantra: string };
}

const FESTIVAL_DATE = new Date('2026-10-05T08:00:00+05:30');

export function Hero({ lang, labels, onNavigate }: HeroProps) {
  const isGu = lang === 'gu';
  return (
    <section style={{ position: 'relative', minHeight: '100svh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', background: '#0D0906' }}>
      {/* Background image */}
      <div style={{ position: 'absolute', inset: 0, zIndex: 0 }}>
        <ImageWithFallback src={bannerImg} alt="Shri Nilkanth Mahadev Maha Mahotsav banner" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center top', filter: 'saturate(0.5) brightness(0.22)' }} />
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg,rgba(13,9,6,0.5) 0%,rgba(13,9,6,0.15) 40%,rgba(13,9,6,0.8) 100%)' }} />
        <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: '80%', height: '50%', background: 'radial-gradient(ellipse 70% 60% at 50% 0%,rgba(200,146,42,0.13) 0%,transparent 70%)' }} />
        <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, height: '35%', background: 'linear-gradient(to top,rgba(13,9,6,1) 0%,transparent 100%)' }} />
      </div>

      {/* Stars */}
      <div style={{ position: 'absolute', inset: 0, zIndex: 1, backgroundImage: 'radial-gradient(1px 1px at 12% 18%,rgba(242,232,213,0.5) 0%,transparent 100%),radial-gradient(1.5px 1.5px at 35% 8%,rgba(200,146,42,0.6) 0%,transparent 100%),radial-gradient(1px 1px at 60% 14%,rgba(242,232,213,0.4) 0%,transparent 100%),radial-gradient(1px 1px at 82% 22%,rgba(200,146,42,0.5) 0%,transparent 100%),radial-gradient(1px 1px at 91% 9%,rgba(242,232,213,0.35) 0%,transparent 100%),radial-gradient(1px 1px at 6% 38%,rgba(200,146,42,0.3) 0%,transparent 100%)' }} />

      {/* Content */}
      <div style={{ position: 'relative', zIndex: 2, textAlign: 'center', padding: 'clamp(88px,12vw,130px) clamp(20px,5vw,80px) clamp(64px,8vw,100px)', maxWidth: '900px', width: '100%', margin: '0 auto', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        {/* OM */}
        <div style={{ marginBottom: '12px', opacity: 0.75 }}>
          <span style={{ fontFamily: 'serif', fontSize: '3.5rem', color: '#C8922A', lineHeight: 1 }}>ॐ</span>
        </div>

        {/* Kicker */}
        <p style={{ fontSize: '0.65rem', letterSpacing: '0.35em', textTransform: 'uppercase', color: '#C8922A', fontFamily: "'Inter',sans-serif", marginBottom: '16px' }}>
          {isGu ? 'શ્રી શિવ' + 'શ' + 'ક' + '્' + 'ત' + 'િ ર' + 'ા' + 'સ મ' + 'ં' + 'ડ' + 'ળ, બ' + 'ા' + 'પ' + 'ુ' + 'પ' + 'ૂ' + 'ર' + 'ા' : 'Shri Shivshakti Ras Mandal, Bapupura'}
        </p>

        {/* Village name */}
        <h1 style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(2.8rem,10vw,6.5rem)' : 'clamp(3.5rem,12vw,8rem)', fontWeight: isGu ? 700 : 300, color: '#F2E8D5', lineHeight: 1.05, marginBottom: '8px', letterSpacing: isGu ? '-0.01em' : '-0.02em' }}>
          {labels.villageName}
        </h1>

        {/* Tagline */}
        <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? 'clamp(1rem,3.5vw,1.6rem)' : 'clamp(1.1rem,3.5vw,1.8rem)', fontStyle: isGu ? 'normal' : 'italic', color: '#C8922A', marginBottom: '4px', fontWeight: isGu ? 500 : 400 }}>
          {labels.tagline}
        </p>

        {/* Sub */}
        <p style={{ fontSize: '0.75rem', color: '#9A8A76', letterSpacing: '0.12em', textTransform: 'uppercase', fontFamily: "'Inter',sans-serif", marginBottom: '40px' }}>
          {labels.subTagline}
        </p>

        {/* Gold rule */}
        <div style={{ width: '160px', height: '1px', background: 'linear-gradient(to right,transparent,#C8922A,transparent)', marginBottom: '36px' }} />

        {/* Countdown */}
        <div style={{ marginBottom: '44px' }}>
          <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '0.95rem' : '1.1rem', color: '#F2E8D5', marginBottom: '5px' }}>
            {labels.countdownTitle}
          </p>
          <p style={{ fontSize: '0.65rem', color: '#9A8A76', letterSpacing: '0.15em', textTransform: 'uppercase', fontFamily: "'Inter',sans-serif", marginBottom: '22px' }}>
            {labels.countdownSub}
          </p>
          <CountdownTimer targetDate={FESTIVAL_DATE} labels={{ days: labels.days, hours: labels.hours, minutes: labels.minutes, seconds: labels.seconds }} />
        </div>

        {/* CTAs */}
        <div style={{ display: 'flex', gap: '14px', flexWrap: 'wrap', justifyContent: 'center' }}>
          <button onClick={() => onNavigate('albums')}
            style={{ padding: '12px 32px', background: '#C8922A', border: 'none', color: '#0D0906', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.9rem' : '0.75rem', fontWeight: 600, letterSpacing: isGu ? 0 : '0.12em', textTransform: isGu ? 'none' : 'uppercase', cursor: 'pointer', transition: 'background 200ms ease-out,transform 150ms ease-out' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = '#E4AE4A'; (e.currentTarget as HTMLElement).style.transform = 'translateY(-1px)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = '#C8922A'; (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; }}
          >{labels.cta1}</button>
          <button onClick={() => onNavigate('upload')}
            style={{ padding: '12px 32px', background: 'transparent', border: '1px solid rgba(200,146,42,0.55)', color: '#C8922A', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.9rem' : '0.75rem', fontWeight: 500, letterSpacing: isGu ? 0 : '0.12em', textTransform: isGu ? 'none' : 'uppercase', cursor: 'pointer', transition: 'border-color 200ms ease-out,color 200ms ease-out,transform 150ms ease-out' }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.borderColor = '#C8922A'; (e.currentTarget as HTMLElement).style.color = '#F2E8D5'; (e.currentTarget as HTMLElement).style.transform = 'translateY(-1px)'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(200,146,42,0.55)'; (e.currentTarget as HTMLElement).style.color = '#C8922A'; (e.currentTarget as HTMLElement).style.transform = 'translateY(0)'; }}
          >{labels.cta2}</button>
        </div>

        {/* Mantra */}
        <p style={{ marginTop: '44px', fontFamily: "'Cormorant Garamond',serif", fontSize: 'clamp(1rem,2.5vw,1.3rem)', color: 'rgba(200,146,42,0.6)', letterSpacing: '0.1em', fontStyle: 'italic' }}>
          {labels.mantra}
        </p>
      </div>

      {/* Scroll bar */}
      <div style={{ position: 'absolute', bottom: '28px', left: '50%', transform: 'translateX(-50%)', zIndex: 2 }}>
        <div style={{ width: '1px', height: '40px', background: 'linear-gradient(to bottom,rgba(200,146,42,0.7),transparent)', animation: 'heroPulse 2s ease-in-out infinite' }} />
        <style>{`@keyframes heroPulse{0%,100%{opacity:.4}50%{opacity:1}}`}</style>
      </div>
    </section>
  );
}
