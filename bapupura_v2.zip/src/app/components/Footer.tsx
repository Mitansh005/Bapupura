import { OrnamentalDivider } from './OrnamentalDivider';

type Page = 'home' | 'about' | 'albums' | 'upload';

interface FooterProps {
  lang: 'en' | 'gu';
  onNavigate: (page: Page) => void;
  labels: { mantra: string; village: string; temple: string; organizer: string; copyright: string; nav: { home: string; about: string; albums: string; upload: string } };
}

export function Footer({ lang, onNavigate, labels }: FooterProps) {
  const isGu = lang === 'gu';
  const navItems: { key: Page; label: string }[] = [
    { key: 'home', label: labels.nav.home },
    { key: 'about', label: labels.nav.about },
    { key: 'albums', label: labels.nav.albums },
    { key: 'upload', label: labels.nav.upload },
  ];
  return (
    <footer style={{ background: '#100C09', borderTop: '1px solid rgba(200,146,42,0.13)', padding: 'clamp(48px,8vw,80px) clamp(20px,5vw,80px) clamp(28px,4vw,44px)' }}>
      <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
        {/* Mantra centrepiece */}
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <OrnamentalDivider symbol="ॐ" />
          <p style={{ fontFamily: "'Cormorant Garamond',serif", fontSize: 'clamp(1.6rem,5vw,3rem)', color: '#C8922A', letterSpacing: '0.1em', fontStyle: 'italic', lineHeight: 1.2, margin: '20px 0' }}>
            {labels.mantra}
          </p>
          <OrnamentalDivider symbol="ॐ" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))', gap: '36px', marginBottom: '44px' }}>
          {/* Village */}
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '14px' }}>
              <svg width="16" height="20" viewBox="0 0 22 28" fill="none"><line x1="11" y1="6" x2="11" y2="27" stroke="rgba(200,146,42,0.5)" strokeWidth="1.5"/><path d="M11 6L7 2M11 6L15 2" stroke="rgba(200,146,42,0.5)" strokeWidth="1.5" strokeLinecap="round"/><path d="M5 2C3 2 2 4 2 6c0 3 3 4 5 2" stroke="rgba(200,146,42,0.5)" strokeWidth="1.2" strokeLinecap="round" fill="none"/><path d="M17 2c2 0 3 2 3 4 0 3-3 4-5 2" stroke="rgba(200,146,42,0.5)" strokeWidth="1.2" strokeLinecap="round" fill="none"/><line x1="8" y1="18" x2="14" y2="18" stroke="rgba(200,146,42,0.5)" strokeWidth="1.2"/></svg>
              <span style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Cormorant Garamond',serif", fontSize: isGu ? '1rem' : '1.15rem', color: '#C8922A', fontWeight: isGu ? 600 : 500 }}>{isGu ? 'બ' + 'ા' + 'પ' + 'ુ' + 'પ' + 'ૂ' + 'ર' + 'ા' : 'Bapupura'}</span>
            </div>
            <p style={{ fontFamily: "'Inter',sans-serif", fontSize: '0.76rem', color: '#9A8A76', lineHeight: 1.7 }}>{labels.village}</p>
            <p style={{ fontFamily: "'Inter',sans-serif", fontSize: '0.76rem', color: '#9A8A76', lineHeight: 1.7, marginTop: '3px' }}>{labels.temple}</p>
          </div>

          {/* Nav */}
          <div>
            <p style={{ fontSize: '0.58rem', letterSpacing: '0.25em', textTransform: 'uppercase', color: 'rgba(154,138,118,0.55)', fontFamily: "'Inter',sans-serif", marginBottom: '14px' }}>
              {isGu ? 'ન' + 'ે' + 'વ' + 'િ' + 'ગ' + 'ે' + 'શ' + 'ન' : 'Navigate'}
            </p>
            <nav style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
              {navItems.map(({ key, label }) => (
                <button key={key} onClick={() => onNavigate(key)} style={{ background: 'none', border: 'none', padding: 0, textAlign: 'left', fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: isGu ? '0.875rem' : '0.78rem', color: '#9A8A76', cursor: 'pointer', transition: 'color 200ms ease-out' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.color = '#C8922A'; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.color = '#9A8A76'; }}
                >{label}</button>
              ))}
            </nav>
          </div>

          {/* Organizer */}
          <div>
            <p style={{ fontSize: '0.58rem', letterSpacing: '0.25em', textTransform: 'uppercase', color: 'rgba(154,138,118,0.55)', fontFamily: "'Inter',sans-serif", marginBottom: '14px' }}>
              {isGu ? 'આ' + 'ય' + 'ો' + 'જ' + 'ક' : 'Organizer'}
            </p>
            <p style={{ fontFamily: isGu ? "'Noto Sans Gujarati',sans-serif" : "'Inter',sans-serif", fontSize: '0.78rem', color: '#9A8A76', lineHeight: 1.7 }}>{labels.organizer}</p>
            <p style={{ fontFamily: "'Inter',sans-serif", fontSize: '0.75rem', color: 'rgba(154,138,118,0.45)', marginTop: '6px' }}>Shri Shivshakti Ras Mandal</p>
          </div>
        </div>

        <div style={{ borderTop: '1px solid rgba(200,146,42,0.08)', paddingTop: '22px', textAlign: 'center' }}>
          <p style={{ fontSize: '0.68rem', color: 'rgba(154,138,118,0.38)', fontFamily: "'Inter',sans-serif", letterSpacing: '0.07em' }}>{labels.copyright}</p>
        </div>
      </div>
    </footer>
  );
}
