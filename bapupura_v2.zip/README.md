
  # Premium Village Website Design

  This is a code bundle for Premium Village Website Design. The original project is available at https://www.figma.com/design/bvCheWyc0xWJloAprarv1g/Premium-Village-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  